import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-addnewemp',
  templateUrl: './addnewemp.component.html',
  styleUrls: ['./addnewemp.component.css']
})
export class AddnewempComponent implements OnInit {

  constructor(private builder:FormBuilder, 
    private empServ:EmployeeService) { }

  ngOnInit(): void {
  }
  msg:string;

  RegFormEmp = this.builder.group({
    id: this.builder.control('', Validators.required),
    firstName: this.builder.control('', Validators.required),
    lastName: this.builder.control('', Validators.required),
    emailId: this.builder.control('', Validators.required), 
});


NewEmployeeAdding()
{
  
   this.empServ.newEmployee(this.RegFormEmp.value).subscribe(data=>{
    this.RegFormEmp.reset();
    this.msg = "Employee Added...";
    });
  }
  

}

import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-all-emps',
  templateUrl: './view-all-emps.component.html',
  styleUrls: ['./view-all-emps.component.css']
})
export class ViewAllEmpsComponent implements OnInit {

  empinfo:Employee[];

  constructor(private empServ:EmployeeService) { }

  ngOnInit(): void {

    this.empServ.GetAllEmployees().subscribe(data=>{
      this.empinfo = data;
    });
  }

}

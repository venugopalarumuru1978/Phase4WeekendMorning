import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-modifyemp',
  templateUrl: './modifyemp.component.html',
  styleUrls: ['./modifyemp.component.css']
})
export class ModifyempComponent implements OnInit {

  idval:number;
  emp:Employee=new Employee();

  constructor(
    private empServ:EmployeeService, 
    private router:Router,
    private aroute:ActivatedRoute, 
    private builder:FormBuilder
  ) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
    this.empServ.GetOneEmployee(this.idval).subscribe(data=>{
      this.emp = data;
      console.log(data);
    });

  }

  msg:string;

  ModifyFormEmp = this.builder.group({
    id: this.builder.control('', Validators.required),
    firstName: this.builder.control('', Validators.required),
    lastName: this.builder.control('', Validators.required),
    emailId: this.builder.control('', Validators.required), 
});

UpdateEmployee()
{
  this.empServ.updateEmployee(this.idval, this.ModifyFormEmp.value).subscribe(data=>{
    console.log(data);
    this.router.navigate(['/viewall']);
  });
}
}

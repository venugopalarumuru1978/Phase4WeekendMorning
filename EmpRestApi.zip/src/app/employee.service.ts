import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  private apiUrl = "http://localhost:9090/api/v1/employees";

  GetAllEmployees(): Observable<Employee[]>
  {
    return this.http.get<Employee[]>(`${this.apiUrl}`);
  }

  newEmployee(employee:Employee):Observable<Object>{
    return this.http.post(`${this.apiUrl}`, employee);
  }

  GetOneEmployee(id:number):Observable<Employee>
  {
    return this.http.get<Employee>(`${this.apiUrl}/${id}`);
  }

  DeleteEmployee(id:number):Observable<Object>
  {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  updateEmployee(id:number, employee:Employee):Observable<Object>
  {
    return this.http.put(`${this.apiUrl}/${id}`, employee);
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AddnewempComponent } from './addnewemp/addnewemp.component';
import { ViewAllEmpsComponent } from './view-all-emps/view-all-emps.component';
import { ModifyempComponent } from './modifyemp/modifyemp.component';
import { ViewoneempComponent } from './viewoneemp/viewoneemp.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    AddnewempComponent,
    ViewAllEmpsComponent,
    ModifyempComponent,
    ViewoneempComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule, 
    HttpClientModule, 
    ReactiveFormsModule, 
    NgxPaginationModule, 
    Ng2OrderModule,
    Ng2SearchPipeModule, 
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-all-emps',
  templateUrl: './view-all-emps.component.html',
  styleUrls: ['./view-all-emps.component.css']
})
export class ViewAllEmpsComponent implements OnInit {

  empinfo:Employee[];
p:number;
  constructor(private empServ:EmployeeService,
    private router:Router) { }

  ngOnInit(): void {
    this.viewAll();
    
  }

  viewAll()
  {
    this.empServ.GetAllEmployees().subscribe(data=>{
      this.empinfo = data;
    });
  }
  deleteEmployee(id:number)
  {
    this.empServ.DeleteEmployee(id).subscribe(data=>{
      this.viewAll();
    });
  }

  modifyEmp(id:number)
  {
    this.router.navigate(['/modemp', id]);
  }

  viewOneEmp(id:number)
  {
    this.router.navigate(['/viewone', id]);
  }

  key:string = "id";
  reverse:boolean=false;

  Sorting(key:any)
  {
    this.key = key;
    this.reverse= !this.reverse;
  }

  firstName:string;
  SearchEmps()
  {
    if(this.firstName=="")
    {
      this.viewAll();
    }
    else
    {
      console.log(this.firstName);
      this.empinfo = this.empinfo.filter(empobj=>{
        return empobj.firstName.toLocaleLowerCase().match(this.firstName);
      });
    }
  }
}

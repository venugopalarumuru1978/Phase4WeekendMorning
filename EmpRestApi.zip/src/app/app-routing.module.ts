import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddnewempComponent } from './addnewemp/addnewemp.component';
import { ModifyempComponent } from './modifyemp/modifyemp.component';
import { ViewAllEmpsComponent } from './view-all-emps/view-all-emps.component';
import { ViewoneempComponent } from './viewoneemp/viewoneemp.component';

const routes: Routes = [
  {path:"", component:ViewAllEmpsComponent},
  {path:"empreg", component:AddnewempComponent},
  {path:"viewall", component:ViewAllEmpsComponent}, 
  {path:"modemp/:id", component:ModifyempComponent},
  {path:"viewone/:id", component:ViewoneempComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

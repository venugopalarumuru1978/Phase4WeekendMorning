import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-viewoneemp',
  templateUrl: './viewoneemp.component.html',
  styleUrls: ['./viewoneemp.component.css']
})
export class ViewoneempComponent implements OnInit {
idval:number;
emp:Employee = new Employee();

  constructor(
    private empServ:EmployeeService, 
    private router:Router,
    private aroute:ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
    this.empServ.GetOneEmployee(this.idval).subscribe(data=>{
      this.emp = data;
    });
  }

}

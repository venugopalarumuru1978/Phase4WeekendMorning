import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewoneempComponent } from './viewoneemp.component';

describe('ViewoneempComponent', () => {
  let component: ViewoneempComponent;
  let fixture: ComponentFixture<ViewoneempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewoneempComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewoneempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

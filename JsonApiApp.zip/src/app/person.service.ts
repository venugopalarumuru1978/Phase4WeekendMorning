import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private http:HttpClient) { }

  private apiUrl = "http://localhost:3000/person";

  CreateNewPerson(personinfo:any) : Observable<any>
  {
    return this.http.post(this.apiUrl, personinfo);
  }

  ViewAllPersonsData() : Observable<any>
  {
    return this.http.get(this.apiUrl);
  }

  ViewPersonDetailsByID(id:any):Observable<any>
  {
    return this.http.get(this.apiUrl + '/' + id);
  }

  DeletePersons(id:any) : Observable<any>
  {
    return this.http.delete(this.apiUrl + '/' + id);
  }
}

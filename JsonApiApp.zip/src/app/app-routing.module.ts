import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModifypersonComponent } from './modifyperson/modifyperson.component';
import { PersonaddComponent } from './personadd/personadd.component';
import { ViewAllPersonsComponent } from './view-all-persons/view-all-persons.component';
import { ViewonepersonComponent } from './viewoneperson/viewoneperson.component';

const routes: Routes = [
  {path:"", component:ViewAllPersonsComponent},
  {path:"register", component:PersonaddComponent},
  {path:"viewall", component:ViewAllPersonsComponent}, 
  {path:"viewone/:id", component:ViewonepersonComponent}, 
  {path:"modify/:id", component:ModifypersonComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

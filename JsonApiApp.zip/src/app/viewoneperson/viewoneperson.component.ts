import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-viewoneperson',
  templateUrl: './viewoneperson.component.html',
  styleUrls: ['./viewoneperson.component.css']
})
export class ViewonepersonComponent implements OnInit {

  idval :any;
  personInfo:any;

  constructor(
    private aroute : ActivatedRoute,  // this class is used to get values from currently viewing url from the browser.
    private router:Router, 
    private personServ:PersonService
  ) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
   this.viewOneInfo();
  }

  viewOneInfo()
  {
    this.personServ.ViewPersonDetailsByID(this.idval).subscribe(data=>{
      this.personInfo = data;
      console.log(this.personInfo);
    });
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewonepersonComponent } from './viewoneperson.component';

describe('ViewonepersonComponent', () => {
  let component: ViewonepersonComponent;
  let fixture: ComponentFixture<ViewonepersonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewonepersonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewonepersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

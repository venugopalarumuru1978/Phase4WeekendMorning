import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-view-all-persons',
  templateUrl: './view-all-persons.component.html',
  styleUrls: ['./view-all-persons.component.css']
})
export class ViewAllPersonsComponent implements OnInit {

  viewallpersoninfo :Observable<any>
  constructor(
    private personServ:PersonService, 
    private router:Router
  ) { }

  ngOnInit(): void {
    this.viewAll();
  }

  viewAll()
  {
    /*
    this.personServ.ViewAllPersonsData().subscribe(data=>{
        console.log(data);
        this.viewallpersoninfo = data;
    });
    */
   this.viewallpersoninfo = this.personServ.ViewAllPersonsData();
  }

  RemovePerson(id:any)
  {
    this.personServ.DeletePersons(id).subscribe(data=>{
      console.log(data);
      //alert("Person Deleted....");
      this.viewAll();
    });
  }

  ViewData(id:any)
  {
    this.router.navigate(['/viewone', id]);
  }

  ModifyData(id:any)
  {
    this.router.navigate(['/modify', id]);
  }
}

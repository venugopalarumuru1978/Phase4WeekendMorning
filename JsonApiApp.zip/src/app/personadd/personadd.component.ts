import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { PersonService } from '../person.service';
@Component({
  selector: 'app-personadd',
  templateUrl: './personadd.component.html',
  styleUrls: ['./personadd.component.css']
})
export class PersonaddComponent implements OnInit {

  msg :string="";
  constructor(
    private builder:FormBuilder, 
    private personServ:PersonService
  ) { }

  ngOnInit(): void {
  }


  regPerson = this.builder.group({
    id: this.builder.control('', [Validators.required]),
    personname: this.builder.control('', [Validators.required]),
    location: this.builder.control('', [Validators.required]),
    phone: this.builder.control('', [Validators.required])
  });


  RegisterPerson()
  {
    this.personServ.CreateNewPerson(this.regPerson.value).subscribe(data=>{
      console.log(data);
      alert("New Person Added...");
      //this.msg = "New Person Added....";
      this.regPerson.reset();
    });
  }
}

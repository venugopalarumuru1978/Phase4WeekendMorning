import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PersonService } from '../person.service';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-modifyperson',
  templateUrl: './modifyperson.component.html',
  styleUrls: ['./modifyperson.component.css']
})
export class ModifypersonComponent implements OnInit {

  idval:any;
  personInfo:any;
  constructor(
    private aroute:ActivatedRoute, 
    private router:Router, 
    private personServ:PersonService, 
    private builder:FormBuilder
  ) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
    this.viewOneInfo();
  }

  viewOneInfo()
  {
    this.personServ.ViewPersonDetailsByID(this.idval).subscribe(data=>{
      this.personInfo = data;
      console.log(this.personInfo);
    });
  }


  modifyPerson = this.builder.group({
    id: this.builder.control('', [Validators.required]),
    personname: this.builder.control('', [Validators.required]),
    location: this.builder.control('', [Validators.required]),
    phone: this.builder.control('', [Validators.required])
  });
}

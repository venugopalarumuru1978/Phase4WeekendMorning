import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PersonaddComponent } from './personadd/personadd.component';
import {HttpClientModule}  from '@angular/common/http';
import { ViewAllPersonsComponent } from './view-all-persons/view-all-persons.component';
import { ViewonepersonComponent } from './viewoneperson/viewoneperson.component';
import { ModifypersonComponent } from './modifyperson/modifyperson.component';
@NgModule({
  declarations: [
    AppComponent,
    PersonaddComponent,
    ViewAllPersonsComponent,
    ViewonepersonComponent,
    ModifypersonComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule, 
    ReactiveFormsModule, 
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

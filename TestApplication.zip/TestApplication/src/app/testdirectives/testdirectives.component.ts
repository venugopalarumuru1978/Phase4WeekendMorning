import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testdirectives',
  templateUrl: './testdirectives.component.html',
  styleUrls: ['./testdirectives.component.css']
})
export class TestdirectivesComponent implements OnInit {
  
  marks:number = 18;
  chk:boolean=false;
  cssclass:string="";
  locations:string[] = ["Hyderabad", "Mumbai", "Kolkatta", "Bangalore", "Amaravathi"];
  country:string;
  constructor() {

    if(this.marks>=35)
      {
        this.chk = true;
        this.cssclass="css2";
      }
    else
    {
      this.chk=false;
      this.cssclass="css1";
    }

   }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-login',
  templateUrl: './test-login.component.html',
  styleUrls: ['./test-login.component.css']
})
export class TestLoginComponent implements OnInit {

  username:string = "";
  password:string = "";
  msg:string = "";
  constructor() { }

  ngOnInit(): void {
  }

  TestLoginDetails()
  {
    if(this.username=="venugopal" && this.password=="12345")
        this.msg = "User Details are Correct";
    else
        this.msg = "Please check username / password";
  }
}

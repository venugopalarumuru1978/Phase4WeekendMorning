export class Employee {
empno:number;
ename:string;
job:string;
salary:number;

constructor(eno:number, ename:string, job:string, sal:number)
{
  this.empno = eno;
  this.ename=ename;
  this.job = job;
  this.salary = sal;  
}


}

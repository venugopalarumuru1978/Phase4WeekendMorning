import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { PipesinfoComponent } from './pipesinfo/pipesinfo.component';
import { SampleComponent } from './sample/sample.component';
import { TestLoginComponent } from './test-login/test-login.component';
import { TestdirectivesComponent } from './testdirectives/testdirectives.component';
import { TestregComponent } from './testreg/testreg.component';

const routes: Routes = [
  {path:"sample", component:SampleComponent},
  {path:"login", component:TestLoginComponent},
  {path:"reg", component:TestregComponent},
  {path:"pipesinfo", component:PipesinfoComponent},
  {path:"dirt", component:TestdirectivesComponent},
  {path:"emp", component:EmployeeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipesinfo',
  templateUrl: './pipesinfo.component.html',
  styleUrls: ['./pipesinfo.component.css']
})
export class PipesinfoComponent implements OnInit {

  pname:string = "Praveen Kumar";
  salary :number = 15000.00;
  dt : Date = new Date();
  pinfo:object = {"firstName":"Raghu", "Age":30};
  mn:number=1200000.00;
  constructor() { }

  ngOnInit(): void {
  }

}

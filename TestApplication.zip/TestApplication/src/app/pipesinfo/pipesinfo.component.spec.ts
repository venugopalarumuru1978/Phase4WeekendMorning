import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PipesinfoComponent } from './pipesinfo.component';

describe('PipesinfoComponent', () => {
  let component: PipesinfoComponent;
  let fixture: ComponentFixture<PipesinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PipesinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipesinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

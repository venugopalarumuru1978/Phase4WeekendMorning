import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SampleComponent } from './sample/sample.component';
import { TestLoginComponent } from './test-login/test-login.component';
import { TestregComponent } from './testreg/testreg.component';
import { TestdirectivesComponent } from './testdirectives/testdirectives.component';
import { EmployeeComponent } from './employee/employee.component';
import { PipesinfoComponent } from './pipesinfo/pipesinfo.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    SampleComponent,
    TestLoginComponent,
    TestregComponent,
    TestdirectivesComponent,
    EmployeeComponent,
    PipesinfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule, NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

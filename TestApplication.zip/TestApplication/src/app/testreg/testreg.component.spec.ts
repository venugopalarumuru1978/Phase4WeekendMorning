import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestregComponent } from './testreg.component';

describe('TestregComponent', () => {
  let component: TestregComponent;
  let fixture: ComponentFixture<TestregComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestregComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestregComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

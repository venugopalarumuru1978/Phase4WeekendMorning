import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  empinfo:Employee[] = [
    new Employee(101, "Ravi", "Developer", 10000.00),
    new Employee(102, "Kavi", "Tester", 9000.00),
    new Employee(103, "Lavi", "HR-Manager", 30000.00),
    new Employee(104, "Bhavi", "Developer", 10000.00),
    new Employee(105, "Kovi", "Tester", 9000.00)
  ];

  emp:Employee= new Employee(0, "", "", 0.0);
  constructor() { }

  ngOnInit(): void {
  }

  addNewEmployee()
  {
    //console.log(this.emp);
    this.empinfo.push(new Employee(this.emp.empno, this.emp.ename, this.emp.job, this.emp.salary));
    this.emp.empno =0;
    this.emp.ename = "";
    this.emp.job = "";
    this.emp.salary = 0.0;
  }

  DeleteEmployee(i:number)
  {
    this.empinfo.splice(i, 1);
  }
}

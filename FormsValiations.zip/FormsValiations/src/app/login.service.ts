import { Injectable } from '@angular/core';
import { Users } from './users';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  usersinfo : Users[] = [
    new Users("pavan", "12345"),
    new Users("kiran", "12345"),
    new Users("lokesh", "12345")
  ];
  constructor() { }

  CheckUserDetails(user:string, pwd:string) :boolean
  {
    var chk = false;
    for(let i=0;i<this.usersinfo.length;i++)
    {
        if(this.usersinfo[i].username==user && this.usersinfo[i].password==pwd)
          chk = true;
    }
    return chk;
  }
}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.css']
})
export class RegFormComponent implements OnInit {
  msg:string="";
  constructor() { }

  ngOnInit(): void {
  }

  registerForm = new FormGroup(
    {
        personname: new FormControl('',[Validators.minLength(5), Validators.required]),
        location: new FormControl('',[Validators.required]),
        phone: new FormControl('',[Validators.minLength(10), Validators.required]),
        email: new FormControl('',[Validators.required])
    });

    ShowRegisterDetails(regform:any)
    {
      if(regform.invalid)
      {
        this.msg = "Form INvalid";
      }
      else
      {
        this.msg = "Person Name : " + this.registerForm.controls.personname.value;
        this.msg += "<br />Location : " + this.registerForm.controls.location.value;
        this.msg += "<br />Phone : " + this.registerForm.controls.phone.value;
        this.msg += "<br />Email : " + this.registerForm.controls.email.value;
      }
    }
}

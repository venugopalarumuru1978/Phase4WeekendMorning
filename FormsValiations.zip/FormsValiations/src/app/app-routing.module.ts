import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegFormBuilderComponent } from './reg-form-builder/reg-form-builder.component';
import { RegFormComponent } from './reg-form/reg-form.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  {path:"", component:LoginComponent},
  {path:"login", component:LoginComponent},
  {path:"welcome", component:WelcomeComponent},
  {path:"reg1", component:RegFormComponent},
  {path:"reg2", component:RegFormBuilderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export class Users {
    username:string;
    password:string;

    constructor(user:string, pwd:string)
    {
        this.username = user;
        this.password = pwd;
    }
}

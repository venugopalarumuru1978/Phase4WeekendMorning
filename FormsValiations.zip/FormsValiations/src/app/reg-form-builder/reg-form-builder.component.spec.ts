import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegFormBuilderComponent } from './reg-form-builder.component';

describe('RegFormBuilderComponent', () => {
  let component: RegFormBuilderComponent;
  let fixture: ComponentFixture<RegFormBuilderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegFormBuilderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegFormBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

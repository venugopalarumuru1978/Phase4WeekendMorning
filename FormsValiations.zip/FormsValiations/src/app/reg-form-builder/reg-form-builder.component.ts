import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-reg-form-builder',
  templateUrl: './reg-form-builder.component.html',
  styleUrls: ['./reg-form-builder.component.css']
})
export class RegFormBuilderComponent implements OnInit {
/*
for any service or predefined class objects, that object has tobe taken as
contructor arguments.
*/
msg:string="";
  constructor(
    private  builder:FormBuilder
  ) { }

  ngOnInit(): void {
  }
/*
 personname: new FormControl('',[Validators.minLength(5), Validators.required]),
        location: new FormControl('',[Validators.required]),
        phone: new FormControl('',[Validators.minLength(10), Validators.required]),
        email: new FormControl('',[Validators.required])
*/

registerForm = this.builder.group({
    personname: this.builder.control('',[Validators.minLength(5), Validators.required]),
    location: this.builder.control('',[Validators.required]),
    phone: this.builder.control('',[Validators.minLength(10), Validators.required]),
    email: this.builder.control('',[Validators.required])
  });

  showDetails(regForm:any)
  {
    if(regForm.invalid)
      this.msg = "Invalid Form";
    else
    {
      console.log(this.registerForm.value);
      this.msg = this.registerForm.value.personname;
      this.msg += "<br />" + this.registerForm.value.location;
      this.msg += "<br />" + this.registerForm.value.phone;
      this.msg += "<br /> " + this.registerForm.value.email;
      }
  }
}

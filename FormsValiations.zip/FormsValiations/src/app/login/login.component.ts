import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string="";
  pswd:string = "";
  msg:string = "";

  constructor(
    private loginServ:LoginService, 
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  checklogindetails(form:any)
  {
    if(form.valid)
    {
      //if(this.username=="venugopal"  && this.pswd=="12345")
      if(this.loginServ.CheckUserDetails(this.username, this.pswd)==true)
        //this.msg= this.username + " Login Details are correct";
        this.router.navigate(['/welcome']);
      else
        this.msg = "Please check username/password";
    }
    else
    {
      this.msg = "Invalid Form";
    }
  }
}
